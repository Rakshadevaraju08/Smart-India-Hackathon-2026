#!/bin/bash

URL_FILE="gpm_urls.txt"
OUT_DIR="gpm_data"

mkdir -p "$OUT_DIR"

grep 'gpm1.gesdisc.eosdis.nasa.gov/daac-bin/OTF/' "$URL_FILE" |
while IFS= read -r url; do

    # Remove hidden CR/newline characters
    url=$(printf '%s' "$url" | tr -d '\r\n')

    # Extract the filename from LABEL=
    filename=$(printf '%s' "$url" | sed -n 's/.*LABEL=\([^&]*\).*/\1/p')

    [ -z "$filename" ] && continue

    # Skip files already downloaded
    if [ -f "$OUT_DIR/$filename" ]; then
        continue
    fi

    printf '%s\n' "$url"
done > remaining_urls.txt

echo "Remaining URLs: $(wc -l < remaining_urls.txt)"

cat remaining_urls.txt | xargs -P 8 -I {} bash -c '
    url="$1"
    filename=$(printf "%s" "$url" | sed -n "s/.*LABEL=\([^&]*\).*/\1/p")

    echo "Downloading: $filename"

    curl -n \
      -b "$HOME/.urs_cookies" \
      -c "$HOME/.urs_cookies" \
      -L \
      --fail \
      --retry 3 \
      --retry-delay 5 \
      --connect-timeout 30 \
      --max-time 300 \
      --url "$url" \
      -o "$OUT_DIR/$filename"

    if [ $? -eq 0 ]; then
        echo "SUCCESS: $filename"
    else
        echo "FAILED: $filename"
        rm -f "$OUT_DIR/$filename"
    fi
' _ {}
OUT_DIR="gpm_data"

